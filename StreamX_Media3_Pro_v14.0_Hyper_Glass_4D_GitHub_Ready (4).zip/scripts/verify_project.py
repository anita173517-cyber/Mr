#!/usr/bin/env python3
"""Comprehensive offline structural, resource-reference, and workflow checks for StreamX Media3 Pro."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors = []

required = [
    root / "settings.gradle.kts",
    root / "build.gradle.kts",
    root / "app/build.gradle.kts",
    root / "app/src/main/AndroidManifest.xml",
    root / "app/src/main/res/layout/activity_player.xml",
    root / "app/src/main/java/com/harindra/iptvpro/PlayerActivity.kt",
    root / "app/src/main/java/com/harindra/iptvpro/NetworkClient.kt",
    root / ".github/workflows/build_apk.yml",
]
for path in required:
    if not path.is_file():
        errors.append(f"Missing required file: {path.relative_to(root)}")

# 1. Parse all XML files
for path in (root / "app/src/main").rglob("*.xml"):
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"Invalid XML {path.relative_to(root)}: {exc}")

# 2. Collect all defined Android resources
defined_drawables = {p.stem for p in (root / "app/src/main/res/drawable").glob("*.xml")}
defined_mipmaps = {p.stem for p in (root / "app/src/main/res/mipmap").glob("*.xml")}
defined_layouts = {p.stem for p in (root / "app/src/main/res/layout").glob("*.xml")}

layout_text = (root / "app/src/main/res/layout/activity_player.xml").read_text(encoding="utf-8")
defined_ids = set(re.findall(r'android:id="@\+?id/([a-zA-Z0-9_]+)"', layout_text))

styles_text = (root / "app/src/main/res/values/styles.xml").read_text(encoding="utf-8")
raw_styles = set(re.findall(r'<style\s+name="([^"]+)"', styles_text))
defined_style_r_names = {s.replace(".", "_") for s in raw_styles}

# 3. Verify all R.id.*, R.drawable.*, R.layout.*, R.style.* references across Kotlin files
for kt_path in (root / "app/src/main/java").rglob("*.kt"):
    kt = kt_path.read_text(encoding="utf-8")
    for ref_id in re.findall(r'(?<!android\.)\bR\.id\.([a-zA-Z0-9_]+)', kt):
        if ref_id not in defined_ids:
            errors.append(f"{kt_path.name}: unresolved R.id.{ref_id}")
    for ref_drw in re.findall(r'(?<!android\.)\bR\.drawable\.([a-zA-Z0-9_]+)', kt):
        if ref_drw not in defined_drawables:
            errors.append(f"{kt_path.name}: unresolved R.drawable.{ref_drw}")
    for ref_lay in re.findall(r'(?<!android\.)\bR\.layout\.([a-zA-Z0-9_]+)', kt):
        if ref_lay not in defined_layouts:
            errors.append(f"{kt_path.name}: unresolved R.layout.{ref_lay}")
    for ref_sty in re.findall(r'(?<!android\.)\bR\.style\.([a-zA-Z0-9_.]+)', kt):
        if "." in ref_sty or ref_sty not in defined_style_r_names:
            errors.append(f"{kt_path.name}: unresolved or invalid R.style.{ref_sty}")

# 4. Verify XML @drawable/* references
for xml_path in (root / "app/src/main").rglob("*.xml"):
    xml_txt = xml_path.read_text(encoding="utf-8")
    for ref_drw in re.findall(r'@drawable/([a-zA-Z0-9_]+)', xml_txt):
        if ref_drw not in defined_drawables:
            errors.append(f"{xml_path.name}: unresolved @drawable/{ref_drw}")
    for ref_mip in re.findall(r'@mipmap/([a-zA-Z0-9_]+)', xml_txt):
        if ref_mip not in defined_mipmaps:
            errors.append(f"{xml_path.name}: unresolved @mipmap/{ref_mip}")

# 5. Verify Gradle & Media3 invariants
build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
if 'val media3Version = "1.11.1"' not in build:
    errors.append("Media3 dependency version is not pinned to 1.11.1")
if len(re.findall(r'implementation\("androidx\.media3:', build)) != 7:
    errors.append("Expected all seven Media3 modules to use the shared 1.11.1 version variable")
if "minSdk = 23" not in build:
    errors.append("minSdk compatibility declaration is missing")

manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
if 'android.intent.category.LAUNCHER' not in manifest or 'android.intent.action.MAIN' not in manifest:
    errors.append("AndroidManifest.xml must declare android.intent.action.MAIN and android.intent.category.LAUNCHER")
if 'android:largeHeap="true"' in manifest:
    errors.append("largeHeap must remain disabled for the 512MB low-RAM target")

player = (root / "app/src/main/java/com/harindra/iptvpro/PlayerActivity.kt").read_text(encoding="utf-8")
if "EXTENSION_RENDERER_MODE_OFF" not in player:
    errors.append("Optional extension decoders should be disabled on the 512MB profile")
if "scheduleTop8Warmup(this@PlayerActivity" in player:
    errors.append("Top-eight speculative warmup must not run during active playback")
for token in (
    "onRenderedFirstFrame",
    "dismissBootSafetyRunnable",
    "setBackBuffer(0, false)",
    "setAudioAttributes(",
    "setHandleAudioBecomingNoisy(true)",
    "show4dGlassListModal",
    "show4dGlassFormModal",
    "createPreloadAwareDataSourceFactory",
    "consumePreparedMediaSource",
):
    if token not in player:
        errors.append(f"Missing expected playback/UI behavior: {token}")

network = (root / "app/src/main/java/com/harindra/iptvpro/NetworkClient.kt").read_text(encoding="utf-8")
for token in ("metadataDispatcher", "apiDispatcher", "streamDispatcher", "readTimeout(20, TimeUnit.SECONDS)"):
    if token not in network:
        errors.append(f"Missing expected network isolation behavior: {token}")

workflow = (root / ".github/workflows/build_apk.yml").read_text(encoding="utf-8")
if "-x lintVitalRelease" in workflow:
    errors.append("Workflow must not pass '-x lintVitalRelease' when checkReleaseBuilds = false in app/build.gradle.kts")

if errors:
    print("FAIL")
    print("\n".join(f" - {e}" for e in errors))
    sys.exit(1)

print("PASS: required project files present")
print(f"PASS: all Android XML resources parse ({len(defined_drawables)} drawables, {len(defined_ids)} view IDs)")
print("PASS: all R.id, R.drawable, R.layout, R.style, and @drawable references resolved")
print("PASS: Media3 artifacts consistently pinned to 1.11.1")
print("PASS: 4D Glass Modal UI, fast zapping engine, and GitHub Actions workflow verified")
