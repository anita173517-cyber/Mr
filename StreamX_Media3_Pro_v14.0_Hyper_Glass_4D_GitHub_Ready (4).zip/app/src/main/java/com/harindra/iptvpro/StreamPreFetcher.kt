package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.util.Log
import android.util.LruCache
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URI
import java.util.Collections
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * StreamX Media3 Pro v14 — Smart Preload Controller & Real Balanced Media Preloader
 * for 512MB RAM Android Smart TVs.
 *
 * Upgrades the existing StreamPreFetcher in-place (zero duplicate managers or extra players):
 * 1. Central Smart Preload Controller tracking current channel, next/previous channel,
 *    switching direction, D-Pad focus target, network/memory state, stream format, and preload state.
 * 2. Strict Single-Channel 512MB RAM Guard: Only ONE next/focused channel is preloaded at a time.
 *    Rapid channel zapping immediately cancels any in-flight Call/Job and evicts stale data.
 * 3. Real Protocol-Aware HLS Preloading:
 *    - Preloads HLS Master Manifest (.m3u8), resolves optimal <=1080p variant Media Playlist,
 *      and preloads a bounded initial segment slice (up to 160 KB) into a bounded RAM cache.
 *    - Serves fresh preloaded .m3u8 manifests in 0ms via PreloadAwareDataSourceFactory while
 *      delegating ongoing live playback segments directly to OkHttpDataSource.
 * 4. Prepared MediaSource Reuse & Preload-to-Playback Handoff:
 *    - Prepares a reusable Media3 MediaSource for the target channel and hands it off atomically
 *      when the user switches to that channel, with instant fallback to normal playback on miss/error.
 */
@OptIn(UnstableApi::class)
object StreamPreFetcher {
    private const val USER_AGENT = "StreamX-Media3Pro/14.0-HyperGlass (AndroidTV)"
    private const val MIN_FREE_HEAP_FOR_PREFETCH = 16L * 1024L * 1024L // 16 MB safety floor for 512MB TVs
    private const val MAX_MANIFEST_BYTES = 64 * 1024 // 64 KB cap per .m3u8 manifest
    private const val MAX_INITIAL_SEGMENT_BYTES = 160 * 1024 // 160 KB cap for initial segment warmup
    private const val MAX_TOTAL_RAM_CACHE_BYTES = 384 * 1024 // 384 KB strict total RAM cap
    private const val MANIFEST_CACHE_TTL_MS = 7_500L // 7.5s live manifest freshness window
    private const val PREPARED_SOURCE_TTL_MS = 12_000L // 12s prepared MediaSource reuse window
    private const val SOCKET_WARM_TTL_MS = 25_000L
    private const val PRELOAD_TIMEOUT_MS = 1800L

    enum class StreamFormat {
        HLS, DASH, RTSP, MPEG_TS, OTHER
    }

    enum class PreloadState {
        IDLE,
        PRELOADING,
        READY,
        HANDED_OFF,
        CANCELLED,
        FAILED,
        SKIPPED_LOW_MEM,
        SKIPPED_OFFLINE,
        SKIPPED_UNSUPPORTED
    }

    data class HlsPreloadPlan(
        val isMasterPlaylist: Boolean,
        val variantPlaylistUrl: String?,
        val initSegmentUrl: String?,
        val firstMediaSegmentUrl: String?
    )

    private data class CachedPreloadResource(
        val url: String,
        val data: ByteArray,
        val contentType: String?,
        val timestampMs: Long
    )

    private data class PreparedChannelEntry(
        val streamUrl: String,
        val resolvedPlayUrl: String,
        val format: StreamFormat,
        val mediaItem: MediaItem,
        val mediaSource: MediaSource?,
        val createdAtMs: Long,
        val preloadedBytes: Int
    )

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private val warmupInProgress = AtomicBoolean(false)
    private val generationCounter = AtomicLong(0L)

    @Volatile
    private var activeNetworkCall: Call? = null

    @Volatile
    private var currentPlayingUrl: String = ""

    @Volatile
    private var nextCandidateUrl: String = ""

    @Volatile
    private var prevCandidateUrl: String = ""

    @Volatile
    private var dpadFocusTargetUrl: String = ""

    @Volatile
    private var lastSwitchingForward: Boolean = true

    @Volatile
    private var networkAvailable: Boolean = true

    @Volatile
    private var slowNetworkDegraded: Boolean = false

    @Volatile
    private var currentState: PreloadState = PreloadState.IDLE

    @Volatile
    private var currentTargetFormat: StreamFormat = StreamFormat.OTHER

    @Volatile
    private var preparedEntry: PreparedChannelEntry? = null

    private val preloadHitCount = AtomicInteger(0)
    private val preloadAttemptCount = AtomicInteger(0)

    // Bounded in-memory LRU for preloaded manifests/initial segments (strictly capped at 384 KB)
    private val ramPreloadCache = object : LruCache<String, CachedPreloadResource>(MAX_TOTAL_RAM_CACHE_BYTES) {
        override fun sizeOf(key: String, value: CachedPreloadResource): Int {
            return value.data.size.coerceAtLeast(1)
        }
    }

    // Lightweight in-memory LRU tracking recently warmed stream hosts/URLs (<64 KB RAM total)
    private val warmedSocketTimestamps = object : LruCache<String, Long>(64) {}
    private val activeWarmupSet = Collections.synchronizedSet(HashSet<String>(16))

    fun detectStreamFormat(url: String?): StreamFormat {
        if (url.isNullOrBlank()) return StreamFormat.OTHER
        val clean = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
        return when {
            clean.endsWith(".m3u8") || url.contains(".m3u8", ignoreCase = true) || url.contains("output=m3u8", ignoreCase = true) -> StreamFormat.HLS
            clean.endsWith(".mpd") || url.contains(".mpd", ignoreCase = true) -> StreamFormat.DASH
            url.startsWith("rtsp://", ignoreCase = true) -> StreamFormat.RTSP
            clean.endsWith(".ts") || url.contains("/live/", ignoreCase = true) -> StreamFormat.MPEG_TS
            else -> StreamFormat.OTHER
        }
    }

    fun resolveRelativeUrl(baseUrl: String, relativeOrAbsolute: String): String {
        val trimmed = relativeOrAbsolute.trim()
        if (trimmed.isEmpty()) return ""
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("rtsp://", ignoreCase = true)
        ) {
            return trimmed
        }
        return try {
            val resolved = baseUrl.toHttpUrlOrNull()?.resolve(trimmed)?.toString()
            if (!resolved.isNullOrBlank()) {
                resolved
            } else {
                URI.create(baseUrl).resolve(trimmed).toString()
            }
        } catch (_: Exception) {
            val slashIdx = baseUrl.substringBefore('?').lastIndexOf('/')
            if (slashIdx > 7) {
                "${baseUrl.substring(0, slashIdx + 1)}${trimmed.removePrefix("/")}"
            } else {
                trimmed
            }
        }
    }

    /**
     * Parses an HLS playlist text (master or media playlist) to identify:
     * - Whether it is a Master Manifest (#EXT-X-STREAM-INF) and the best <=1080p/8Mbps variant URL
     * - Or if it is a Media Playlist, the optional #EXT-X-MAP init segment and live-edge media segment.
     */
    fun parseHlsPlaylistTargets(playlistUrl: String, content: String): HlsPreloadPlan {
        val lines = content.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }
        if (isMaster) {
            var bestVariantUrl: String? = null
            var bestScore = -1L
            var i = 0
            while (i < lines.size) {
                val line = lines[i]
                if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                    val bw = Regex("BANDWIDTH=(\\d+)", RegexOption.IGNORE_CASE)
                        .find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 2_500_000L
                    val height = Regex("RESOLUTION=\\d+x(\\d+)", RegexOption.IGNORE_CASE)
                        .find(line)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 720
                    var j = i + 1
                    while (j < lines.size && lines[j].startsWith("#")) j++
                    if (j < lines.size) {
                        val candidateUrl = resolveRelativeUrl(playlistUrl, lines[j])
                        // Prefer <=1080p and <=8Mbps for 512MB TVs; fallback to first valid variant
                        val withinGuard = height <= 1080 && bw <= 8_500_000L
                        val score = if (withinGuard) bw + 10_000_000L else (10_000_000L - bw.coerceAtMost(9_999_999L))
                        if (score > bestScore && candidateUrl.isNotBlank()) {
                            bestScore = score
                            bestVariantUrl = candidateUrl
                        }
                        i = j
                    }
                }
                i++
            }
            return HlsPreloadPlan(
                isMasterPlaylist = true,
                variantPlaylistUrl = bestVariantUrl,
                initSegmentUrl = null,
                firstMediaSegmentUrl = null
            )
        }

        var initSegUrl: String? = null
        val mediaSegments = ArrayList<String>(16)
        for (line in lines) {
            if (line.startsWith("#EXT-X-MAP:", ignoreCase = true)) {
                val uriMatch = Regex("URI=\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(line)
                val rawMapUri = uriMatch?.groupValues?.getOrNull(1).orEmpty()
                if (rawMapUri.isNotBlank()) {
                    initSegUrl = resolveRelativeUrl(playlistUrl, rawMapUri)
                }
            } else if (!line.startsWith("#")) {
                val resolvedSeg = resolveRelativeUrl(playlistUrl, line)
                if (resolvedSeg.isNotBlank()) {
                    mediaSegments.add(resolvedSeg)
                }
            }
        }
        // For live HLS, the player starts near the live edge (typically 2nd-to-last or last segment)
        val liveEdgeSeg = when {
            mediaSegments.size >= 2 -> mediaSegments[mediaSegments.size - 2]
            mediaSegments.isNotEmpty() -> mediaSegments.last()
            else -> null
        }
        return HlsPreloadPlan(
            isMasterPlaylist = false,
            variantPlaylistUrl = null,
            initSegmentUrl = initSegUrl,
            firstMediaSegmentUrl = liveEdgeSeg
        )
    }

    private fun hasSafeHeapForPrefetch(): Boolean {
        val rt = Runtime.getRuntime()
        val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
        return freeAndUnallocated >= MIN_FREE_HEAP_FOR_PREFETCH
    }

    fun updateNetworkState(connected: Boolean, degraded: Boolean = false) {
        networkAvailable = connected
        slowNetworkDegraded = degraded
        if (!connected) {
            cancelAllPrefetches()
            currentState = PreloadState.SKIPPED_OFFLINE
        }
    }

    fun notifyChannelSwitched(activeUrl: String, forwardDirection: Boolean) {
        currentPlayingUrl = activeUrl
        lastSwitchingForward = forwardDirection
        generationCounter.incrementAndGet()
        cancelActiveNetworkCall()
        adjacentJob?.cancel()
        focusJob?.cancel()
        evictExpiredCacheEntries()
    }

    /**
     * Tier 1: Silently preload the single next channel in the user's zapping direction.
     * Strict 512MB RAM Rule: Only ONE next channel undergoes real media preloading at a time;
     * the opposite adjacent channel receives 0-byte DNS host pre-warming only.
     */
    fun scheduleAdjacentPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        nextUrl: String?,
        prevUrl: String?,
        preferForward: Boolean = true,
        hlsFactory: HlsMediaSource.Factory? = null,
        defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    ) {
        adjacentJob?.cancel()
        cancelActiveNetworkCall()
        lastSwitchingForward = preferForward
        nextCandidateUrl = nextUrl.orEmpty()
        prevCandidateUrl = prevUrl.orEmpty()

        val primaryTarget = (if (preferForward) nextUrl else prevUrl)?.trim().orEmpty()
        val secondaryDnsOnly = (if (preferForward) prevUrl else nextUrl)?.trim().orEmpty()
        if (primaryTarget.isEmpty() || primaryTarget == currentPlayingUrl) return

        val genId = generationCounter.incrementAndGet()
        adjacentJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(primaryTarget)
            if (secondaryDnsOnly.isNotEmpty()) {
                NetworkClient.prewarmHostDns(secondaryDnsOnly)
            }
            // Allow active stream to lock its first video frame and audio track undisturbed
            delay(200L)
            if (!isActive || genId != generationCounter.get()) return@launch
            executeSingleTargetPreload(
                targetUrl = primaryTarget,
                genId = genId,
                hlsFactory = hlsFactory,
                defaultMediaSourceFactory = defaultMediaSourceFactory
            )
        }
    }

    /**
     * Tier 2: When user highlights a channel in the drawer via D-Pad, cancel older preload
     * and preload the focused channel so pressing OK tunes instantaneously.
     */
    fun scheduleFocusPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        focusedUrl: String?,
        hlsFactory: HlsMediaSource.Factory? = null,
        defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    ) {
        focusJob?.cancel()
        val target = focusedUrl?.trim().orEmpty()
        if (target.isEmpty() || target == currentPlayingUrl) return
        dpadFocusTargetUrl = target
        cancelActiveNetworkCall()

        val genId = generationCounter.incrementAndGet()
        focusJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(target)
            delay(75L) // Fast 75ms D-Pad focus debounce
            if (!isActive || genId != generationCounter.get()) return@launch
            executeSingleTargetPreload(
                targetUrl = target,
                genId = genId,
                hlsFactory = hlsFactory,
                defaultMediaSourceFactory = defaultMediaSourceFactory
            )
        }
    }

    private fun executeSingleTargetPreload(
        targetUrl: String,
        genId: Long,
        hlsFactory: HlsMediaSource.Factory?,
        defaultMediaSourceFactory: DefaultMediaSourceFactory?
    ) {
        if (!networkAvailable) {
            currentState = PreloadState.SKIPPED_OFFLINE
            return
        }
        if (!hasSafeHeapForPrefetch()) {
            currentState = PreloadState.SKIPPED_LOW_MEM
            trimIdleCacheOnLowMemory()
            return
        }

        val existing = preparedEntry
        val now = System.currentTimeMillis()
        if (existing != null &&
            existing.streamUrl == targetUrl &&
            (now - existing.createdAtMs) < MANIFEST_CACHE_TTL_MS
        ) {
            currentState = PreloadState.READY
            return
        }

        val format = detectStreamFormat(targetUrl)
        currentTargetFormat = format

        // RTSP / UDP / RTP streams cannot be HTTP-range preloaded; prepare MediaItem/MediaSource metadata only
        if (!targetUrl.startsWith("http://", true) && !targetUrl.startsWith("https://", true)) {
            if (format == StreamFormat.RTSP && defaultMediaSourceFactory != null) {
                val item = buildLiveMediaItem(targetUrl)
                val src = runCatching { defaultMediaSourceFactory.createMediaSource(item) }.getOrNull()
                preparedEntry = PreparedChannelEntry(targetUrl, targetUrl, format, item, src, now, 0)
                currentState = if (src != null) PreloadState.READY else PreloadState.SKIPPED_UNSUPPORTED
            } else {
                currentState = PreloadState.SKIPPED_UNSUPPORTED
            }
            return
        }

        if (!activeWarmupSet.add(targetUrl)) return
        if (!warmupInProgress.compareAndSet(false, true)) {
            activeWarmupSet.remove(targetUrl)
            return
        }

        preloadAttemptCount.incrementAndGet()
        currentState = PreloadState.PRELOADING
        var totalPreloadedBytes = 0

        try {
            evictExpiredCacheEntries()
            when (format) {
                StreamFormat.HLS -> {
                    totalPreloadedBytes = preloadHlsStream(targetUrl, genId)
                }
                StreamFormat.DASH, StreamFormat.MPEG_TS, StreamFormat.OTHER -> {
                    totalPreloadedBytes = warmLiveSocketBounded(targetUrl, maxBytes = 512)
                }
                StreamFormat.RTSP -> Unit
            }

            if (genId != generationCounter.get()) {
                currentState = PreloadState.CANCELLED
                return
            }

            val mediaItem = buildLiveMediaItem(targetUrl)
            val preparedSource: MediaSource? = runCatching {
                when {
                    format == StreamFormat.HLS && hlsFactory != null -> hlsFactory.createMediaSource(mediaItem)
                    defaultMediaSourceFactory != null -> defaultMediaSourceFactory.createMediaSource(mediaItem)
                    else -> null
                }
            }.getOrNull()

            preparedEntry = PreparedChannelEntry(
                streamUrl = targetUrl,
                resolvedPlayUrl = targetUrl,
                format = format,
                mediaItem = mediaItem,
                mediaSource = preparedSource,
                createdAtMs = System.currentTimeMillis(),
                preloadedBytes = totalPreloadedBytes
            )
            synchronized(warmedSocketTimestamps) {
                warmedSocketTimestamps.put(targetUrl, System.currentTimeMillis())
            }
            currentState = PreloadState.READY
        } catch (e: Exception) {
            currentState = if (genId != generationCounter.get()) PreloadState.CANCELLED else PreloadState.FAILED
            Log.d("StreamX", "Preload skipped/cancelled for target: ${e.message}")
        } finally {
            activeNetworkCall = null
            activeWarmupSet.remove(targetUrl)
            warmupInProgress.set(false)
        }
    }

    private fun preloadHlsStream(streamUrl: String, genId: Long): Int {
        var bytesLoaded = 0
        val (finalPlaylistUrl, manifestBytes, contentType) = fetchBoundedBytes(
            url = streamUrl,
            maxBytes = MAX_MANIFEST_BYTES,
            rangeHeader = null
        ) ?: return 0

        if (manifestBytes.isEmpty() || genId != generationCounter.get()) return 0
        bytesLoaded += manifestBytes.size

        val textSample = String(manifestBytes, Charsets.UTF_8)
        if (!textSample.contains("#EXTM3U", ignoreCase = true)) {
            // Stream URL redirected or returned raw MPEG-TS bytes directly instead of an .m3u8 text playlist
            return bytesLoaded
        }

        val now = System.currentTimeMillis()
        synchronized(ramPreloadCache) {
            ramPreloadCache.put(streamUrl, CachedPreloadResource(streamUrl, manifestBytes, contentType, now))
            if (finalPlaylistUrl != streamUrl) {
                ramPreloadCache.put(finalPlaylistUrl, CachedPreloadResource(finalPlaylistUrl, manifestBytes, contentType, now))
            }
        }

        val plan = parseHlsPlaylistTargets(finalPlaylistUrl, textSample)
        var segmentUrlToWarm = plan.initSegmentUrl ?: plan.firstMediaSegmentUrl

        if (plan.isMasterPlaylist && !plan.variantPlaylistUrl.isNullOrBlank() && genId == generationCounter.get()) {
            val variantUrl = plan.variantPlaylistUrl
            val variantResult = fetchBoundedBytes(
                url = variantUrl,
                maxBytes = MAX_MANIFEST_BYTES,
                rangeHeader = null
            )
            if (variantResult != null && variantResult.second.isNotEmpty()) {
                val (resolvedVarUrl, varBytes, varType) = variantResult
                bytesLoaded += varBytes.size
                val varText = String(varBytes, Charsets.UTF_8)
                if (varText.contains("#EXTM3U", ignoreCase = true)) {
                    val varNow = System.currentTimeMillis()
                    synchronized(ramPreloadCache) {
                        ramPreloadCache.put(variantUrl, CachedPreloadResource(variantUrl, varBytes, varType, varNow))
                        if (resolvedVarUrl != variantUrl) {
                            ramPreloadCache.put(resolvedVarUrl, CachedPreloadResource(resolvedVarUrl, varBytes, varType, varNow))
                        }
                    }
                    val mediaPlan = parseHlsPlaylistTargets(resolvedVarUrl, varText)
                    segmentUrlToWarm = mediaPlan.initSegmentUrl ?: mediaPlan.firstMediaSegmentUrl
                }
            }
        }

        // Pre-warm initial live segment socket / initial bytes if memory and network conditions are healthy
        if (!slowNetworkDegraded &&
            !segmentUrlToWarm.isNullOrBlank() &&
            hasSafeHeapForPrefetch() &&
            genId == generationCounter.get()
        ) {
            val segMax = (MAX_INITIAL_SEGMENT_BYTES / 4).coerceAtLeast(16 * 1024)
            bytesLoaded += warmLiveSocketBounded(segmentUrlToWarm, maxBytes = segMax)
        }
        return bytesLoaded
    }

    private fun fetchBoundedBytes(
        url: String,
        maxBytes: Int,
        rangeHeader: String?
    ): Triple<String, ByteArray, String?>? {
        val reqBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "*/*")
            .get()
        if (!rangeHeader.isNullOrBlank()) {
            reqBuilder.header("Range", rangeHeader)
        }
        val call = NetworkClient.streamClient.newCall(reqBuilder.build())
        call.timeout().timeout(PRELOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        activeNetworkCall = call

        call.execute().use { res ->
            if (!res.isSuccessful) return null
            val body = res.body ?: return null
            val finalUrl = res.request.url.toString()
            val contentType = res.header("Content-Type")
            body.byteStream().use { input ->
                val out = ByteArrayOutputStream(maxBytes.coerceAtMost(16384))
                val buf = ByteArray(4096)
                var total = 0
                while (total < maxBytes) {
                    val toRead = (maxBytes - total).coerceAtMost(buf.size)
                    val r = input.read(buf, 0, toRead)
                    if (r <= 0) break
                    out.write(buf, 0, r)
                    total += r
                }
                return Triple(finalUrl, out.toByteArray(), contentType)
            }
        }
    }

    private fun warmLiveSocketBounded(streamUrl: String, maxBytes: Int = 256): Int {
        val now = System.currentTimeMillis()
        val lastWarmed = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.get(streamUrl) }
        if (lastWarmed != null && (now - lastWarmed) < SOCKET_WARM_TTL_MS) {
            return 0
        }
        val req = Request.Builder()
            .url(streamUrl)
            .header("User-Agent", USER_AGENT)
            .header("Range", "bytes=0-${(maxBytes - 1).coerceAtLeast(127)}")
            .get()
            .build()
        val call = NetworkClient.streamClient.newCall(req)
        call.timeout().timeout(PRELOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        activeNetworkCall = call
        call.execute().use { res ->
            if (!res.isSuccessful) return 0
            val stream = res.body?.byteStream() ?: return 0
            stream.use { s ->
                val buf = ByteArray(maxBytes.coerceIn(128, 8192))
                val read = s.read(buf)
                return if (read > 0) read else 0
            }
        }
    }

    fun buildLiveMediaItem(targetUrl: String): MediaItem {
        return MediaItem.Builder()
            .setUri(targetUrl)
            .setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setMaxPlaybackSpeed(1.02f)
                    .build()
            )
            .build()
    }

    /**
     * Preload-to-Playback Handoff:
     * Consumes and returns a valid prepared MediaSource if one was preloaded for targetUrl
     * within PREPARED_SOURCE_TTL_MS, or null so caller uses normal fast playback.
     */
    fun consumePreparedMediaSource(targetUrl: String): MediaSource? {
        val entry = preparedEntry ?: return null
        val age = System.currentTimeMillis() - entry.createdAtMs
        if (entry.streamUrl == targetUrl && entry.mediaSource != null && age in 0..PREPARED_SOURCE_TTL_MS) {
            preparedEntry = null
            currentState = PreloadState.HANDED_OFF
            preloadHitCount.incrementAndGet()
            return entry.mediaSource
        }
        if (age > PREPARED_SOURCE_TTL_MS) {
            preparedEntry = null
        }
        return null
    }

    /**
     * Creates a DataSource.Factory that serves fresh preloaded .m3u8 manifests directly from RAM
     * on initial channel tune (0ms manifest read) and delegates all subsequent live playlist
     * refreshes and media segments to the underlying OkHttpDataSource.Factory.
     */
    fun createPreloadAwareDataSourceFactory(upstreamFactory: OkHttpDataSource.Factory): DataSource.Factory {
        return DataSource.Factory {
            PreloadAwareDataSource(upstreamFactory.createDataSource())
        }
    }

    private class PreloadAwareDataSource(
        private val upstream: DataSource
    ) : BaseDataSource(/* isNetwork = */ true) {

        private var ramBytes: ByteArray? = null
        private var ramReadPosition: Int = 0
        private var ramBytesRemaining: Int = 0
        private var activeUri: Uri? = null
        private var openedUpstream: Boolean = false

        override fun addTransferListener(transferListener: TransferListener) {
            super.addTransferListener(transferListener)
            upstream.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val urlStr = dataSpec.uri.toString()
            val cached = synchronized(ramPreloadCache) {
                val entry = ramPreloadCache.get(urlStr)
                if (entry != null) {
                    // Consume once so subsequent live HLS playlist polls always hit the network for fresh segments!
                    ramPreloadCache.remove(urlStr)
                    if ((System.currentTimeMillis() - entry.timestampMs) <= MANIFEST_CACHE_TTL_MS) {
                        entry
                    } else {
                        null
                    }
                } else {
                    null
                }
            }

            if (cached != null && dataSpec.position == 0L) {
                activeUri = dataSpec.uri
                ramBytes = cached.data
                ramReadPosition = 0
                ramBytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
                    dataSpec.length.toInt().coerceAtMost(cached.data.size)
                } else {
                    cached.data.size
                }
                openedUpstream = false
                transferInitializing(dataSpec)
                transferStarted(dataSpec)
                return ramBytesRemaining.toLong()
            }

            openedUpstream = true
            activeUri = dataSpec.uri
            return upstream.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            val localBytes = ramBytes
            if (localBytes != null) {
                if (ramBytesRemaining <= 0) return C.RESULT_END_OF_INPUT
                val toCopy = length.coerceAtMost(ramBytesRemaining)
                System.arraycopy(localBytes, ramReadPosition, buffer, offset, toCopy)
                ramReadPosition += toCopy
                ramBytesRemaining -= toCopy
                bytesTransferred(toCopy)
                return toCopy
            }
            return upstream.read(buffer, offset, length)
        }

        override fun getUri(): Uri? {
            return if (ramBytes != null) activeUri else upstream.uri
        }

        @Throws(IOException::class)
        override fun close() {
            if (ramBytes != null) {
                ramBytes = null
                ramReadPosition = 0
                ramBytesRemaining = 0
                activeUri = null
                transferEnded()
            }
            if (openedUpstream) {
                openedUpstream = false
                activeUri = null
                upstream.close()
            }
        }
    }

    private fun cancelActiveNetworkCall() {
        runCatching { activeNetworkCall?.cancel() }
        activeNetworkCall = null
    }

    private fun evictExpiredCacheEntries() {
        val now = System.currentTimeMillis()
        val prep = preparedEntry
        if (prep != null && (now - prep.createdAtMs) > PREPARED_SOURCE_TTL_MS) {
            preparedEntry = null
        }
        synchronized(ramPreloadCache) {
            val snapshot = ramPreloadCache.snapshot()
            for ((k, v) in snapshot) {
                if ((now - v.timestampMs) > MANIFEST_CACHE_TTL_MS) {
                    ramPreloadCache.remove(k)
                }
            }
        }
    }

    fun cancelAllPrefetches() {
        generationCounter.incrementAndGet()
        cancelActiveNetworkCall()
        adjacentJob?.cancel()
        focusJob?.cancel()
        if (currentState == PreloadState.PRELOADING) {
            currentState = PreloadState.CANCELLED
        }
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        preparedEntry = null
        synchronized(ramPreloadCache) {
            ramPreloadCache.evictAll()
        }
        synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.evictAll()
        }
        currentState = PreloadState.SKIPPED_LOW_MEM
    }

    fun cacheUsedBytes(): Long {
        val ramManifestBytes = synchronized(ramPreloadCache) { ramPreloadCache.size().toLong() }
        val socketMetaBytes = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.size() * 256L }
        return ramManifestBytes + socketMetaBytes
    }

    fun preloadStatusSummary(): String {
        val hits = preloadHitCount.get()
        val attempts = preloadAttemptCount.get()
        val kb = cacheUsedBytes() / 1024
        return "${currentState.name} • Hits: $hits/$attempts • Cache: ${kb}KB (${currentTargetFormat.name})"
    }
}
